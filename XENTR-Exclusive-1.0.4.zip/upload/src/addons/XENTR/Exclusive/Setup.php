<?php

/*
 * Created on 10.08.2020
 * HomePage: https://xentr.net
 * Copyright (c) 2020 XENTR | XenForo Add-ons - Styles -  All Rights Reserved
 */

namespace XENTR\Exclusive;

use XF\AddOn\AbstractSetup;
use XF\Db\Schema\Alter;
use XF\Db\Schema\Create;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;
	
	public function installStep1(array $stepParams = [])
	{
        $this->schemaManager()->alterTable('xf_category', function(Alter $table)
        {
            $table->addColumn('block_header_image', 'int')->setDefault(0);
        }); 
	}

	public function upgrade(array $stepParams = [])
	{
		// TODO: Implement upgrade() method.
	}

	public function uninstallStep1(array $stepParams = [])
	{
        $this->schemaManager()->alterTable('xf_category', function(Alter $table)
        {
            $table->dropColumns('block_header_image');
            
        });
	}
}