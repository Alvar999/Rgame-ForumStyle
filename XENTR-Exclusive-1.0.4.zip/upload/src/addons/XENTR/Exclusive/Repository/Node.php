<?php

/*
 * Created on 10.08.2020
 * HomePage: https://xentr.net
 * Copyright (c) 2020 XENTR | XenForo Add-ons - Styles -  All Rights Reserved
 */
 
namespace XENTR\Exclusive\Repository;

use XF\Mvc\Entity\AbstractCollection;
use XF\Mvc\Entity\Repository;

class Node extends Repository
{
    public function setNodeImageFromUpload($node, $upload)
    {
        $upload->requireImage();

        if (!$upload->isValid($errors))
		{
			throw new \XF\PrintableException(reset($errors));
        }
        
        $target = 'data://blockheader/'.$node->node_id.'.jpg';

        try
		{
			$image = \XF::app()->imageManager->imageFromFile($upload->getTempFile());
			
			$tempFile = \XF\Util\File::getTempFile();
			if ($tempFile && $image->save($tempFile))
			{
				$output = $tempFile;
			}
			unset($image);
			
			\XF\Util\File::copyFileToAbstractedPath($output, $target);
		}
		catch (Exception $e)
		{
			throw new \XF\PrintableException(\XF::phrase('unexpected_error_occurred'));
		}
	}
	
	public function deleteNodeImage($node){
        $nodeImage = 'data://blockheader/'. $node->node_id .'.jpg';
		
		if (\XF\Util\File::abstractedPathExists($nodeImage))
		{
			\XF\Util\File::deleteFromAbstractedPath($nodeImage);
		}
	}
	
}