<?php

/*
 * Created on 10.08.2020
 * HomePage: https://xentr.net
 * Copyright (c) 2020 XENTR | XenForo Add-ons - Styles -  All Rights Reserved
 */
 
namespace XENTR\Exclusive\XF\Entity;

use XF\Mvc\Entity\Entity;
use XF\Mvc\Entity\Structure;


class Category extends XFCP_Category
{
    public function getNodeImage()
    {
        $nodeImage = 'data://blockheader/'.$this->node_id.'.jpg';
		
		if (\XF\Util\File::abstractedPathExists($nodeImage))
		{
			return $this->app()->applyExternalDataUrl('blockheader/' . $this->node_id . '.jpg?' . $this->block_header_image, true);
		}
	
		return;
    }

    protected function _preSave()
    {
        $this->block_header_image = \XF::$time;
    }

    protected function _postDelete()
	{
        \XF\Util\File::deleteFromAbstractedPath('data://blockheader/'.$this->node_id.'.jpg');
    }
    
    public static function getStructure(Structure $structure)
    {
        $structure = parent::getStructure($structure);

        $structure->columns['block_header_image'] = ['type' => self::INT, 'default' => 0];

        return $structure;
    }
}