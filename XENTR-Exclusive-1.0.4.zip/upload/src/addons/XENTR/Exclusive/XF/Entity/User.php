<?php

/*
 * Created on 10.08.2020
 * HomePage: https://xentr.net
 * Copyright (c) 2019 XENTR | XenForo Add-ons - Styles -  All Rights Reserved
 */
 
namespace XENTR\Exclusive\XF\Entity;

use XF\Mvc\Entity\Entity;

class User extends XFCP_User
{
    public function canEditImage(&$error = null)
    {
        $visitor = \XF::visitor();

        if ($visitor->hasPermission('forum', 'canEditImage'))
        {
            return true;
        }

        return false;
    }
}