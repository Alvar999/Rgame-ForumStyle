<?php

/*
 * Created on 10.08.2020
 * HomePage: https://xentr.net
 * Copyright (c) 2020 XENTR | XenForo Add-ons - Styles -  All Rights Reserved
 */
 
namespace XENTR\Exclusive\XF\Admin\Controller;

use XF\Mvc\ParameterBag;

class Category extends XFCP_Category
{
    protected function nodeSaveProcess(\XF\Entity\Node $node)
    {
        if ($upload = $this->request->getFile('upload', false, false))
        {
            $this->repository('XENTR\Exclusive:Node')->setNodeImageFromUpload($node, $upload);
        }

        return parent::nodeSaveProcess($node);
    }
	
	public function actionDeleteNodeImage(ParameterBag $params){
		$node = $this->assertNodeExists($params['node_id']);
		
		if ($this->isPost())
		{
            $this->repository('XENTR\Exclusive:Node')->deleteNodeImage($node);

			return $this->redirect($this->buildLink('nodes') . $this->buildLinkHash($node->node_id));
		}
		else
		{
			$viewParams = [
				'node' => $node
			];
			return $this->view('XENTR\Exclusive:DeleteNodeImage', 'xentr_delete_block_header_image', $viewParams);
		}
	}
	
}