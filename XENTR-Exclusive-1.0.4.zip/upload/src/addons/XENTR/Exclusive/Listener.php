<?php

/*
 * Created on 10.08.2020
 * HomePage: https://xentr.net
 * Copyright (c) 2020 XENTR | XenForo Add-ons - Styles -  All Rights Reserved
 */

namespace XENTR\Exclusive;

use XF\Mvc\Entity\Entity;


class Listener
{
    public static function nodeEntityStructure(\XF\Mvc\Entity\Manager $em, \XF\Mvc\Entity\Structure &$structure)
    {
        $structure->columns['block_header_image'] = ['type' => Entity::UINT, 'default' => '', 'nullable' => true];
    }
	
	public static function templater_template_pre_render(\XF\Template\Templater $templater, &$type, &$template, array &$params)
    {
        if($template == 'PAGE_CONTAINER')
        {
            if(!file_exists(\XF::getRootDirectory() . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'addons' . DIRECTORY_SEPARATOR . 'XENTR' . DIRECTORY_SEPARATOR . 'copyright.txt'))
            {
                $params['xtrExlCopyright'] = '<a href="https://xentr.net/" class="u-concealed" dir="ltr" target="_blank">Xenforo Theme by<span class="copyright"> &copy; XenTR</span></a>';
            }
        }
    }
    
    public static function preRender(\XF\Template\Templater $templater, &$type, &$template, array &$params)
    {
        $params['xentr_statistics'] = \XF::app()->forumStatistics;
    }

}